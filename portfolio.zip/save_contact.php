<?php
// Connect DB
$pdo = new PDO("mysql:host=localhost;dbname=portfolio_db", "root", "");

// Insert data
$stmt = $pdo->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
$stmt->execute([$_POST['name'], $_POST['email'], $_POST['message']]);

// Redirect back to contact page
header("Location: contact.php");
exit;
?>
