<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { background:#0f051e; color:#fff; font-family:sans-serif; margin:0; padding:0; }
.container { max-width:700px; margin:30px auto; background:#1e1e2f; padding:20px; border-radius:10px; }
input, textarea, button { width:100%; margin:10px 0; padding:10px; border-radius:5px; border:none; }
button { background:#28a745; color:#fff; cursor:pointer; }
button:hover { background:#218838; }
table { width:100%; border-collapse:collapse; margin-top:20px; background:#333; }
th, td { padding:8px; border:1px solid #555; }
th { background:#444; }
nav { background:#333; padding:10px 20px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; }
nav a { color:#fff; margin:5px 10px; text-decoration:none; font-size:16px; }
nav a:hover { color:#ffcc00; }

/* Responsive table */
table { font-size:14px; }
@media (max-width: 768px) {
    table, thead, tbody, th, td, tr {
        display: block;
    }
    thead tr {
        display: none;
    }
    tr {
        margin-bottom: 15px;
        background: #222;
        padding: 10px;
        border-radius: 5px;
    }
    td {
        position: relative;
        padding-left: 50%;
        text-align: right;
    }
    td::before {
        position: absolute;
        left: 10px;
        top: 10px;
        white-space: nowrap;
        font-weight: bold;
    }
    td:nth-of-type(1)::before { content: "ID"; }
    td:nth-of-type(2)::before { content: "Name"; }
    td:nth-of-type(3)::before { content: "Email"; }
    td:nth-of-type(4)::before { content: "Message"; }
    td:nth-of-type(5)::before { content: "Date"; }
}

/* Form + container responsiveness */
@media (max-width: 768px) {
    .container {
        padding: 15px;
        margin: 15px;
    }
    input, textarea, button {
        font-size: 14px;
    }
    nav {
        flex-direction: column;
        align-items: flex-start;
    }
    nav a {
        margin: 5px 0;
    }
}
nav {
    background: #333;
    padding: 10px 20px;
    display: flex;
    justify-content: flex-end;  /* Align items to the right */
    align-items: center;
    flex-wrap: wrap;
    border-radius: 5px;
}

nav .nav-links {
    display: flex;
    gap: 15px; /* spacing between links */
    flex-wrap: wrap;
}

nav .nav-links a {
    color: #fff;
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 5px;
    transition: background 0.3s ease, color 0.3s ease;
}

nav .nav-links a:hover {
    background: #444;
    color: #ffcc00;
}
.nav-links a {
    background: #222;  /* Add background */
    padding: 8px 12px;
    border-radius: 5px;
    color: #fff;
    text-decoration: none;
    transition: background 0.3s ease, color 0.3s ease;
}

.nav-links a:hover {
    background: #444;
    color: #ffcc00;
}



</style>
</head>
<body>
<nav>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="about.html">About</a>
        <a href="certificate.html">Certificate</a>
        <a href="projects.html">Projects</a>
        <a href="contact.php" class="active">Contact</a>
        <?php if (isset($_SESSION['logged_in'])): ?>
        <a href="index.php?logout=1" style="background: #900; color: #fff; border-radius: 5px; padding: 8px 12px;">Logout</a>
        <?php endif; ?>
    </div>
</nav>

<div class="container">
<h2>Contact Me</h2>
<form method="POST" action="save_contact.php">
  <input type="text" name="name" placeholder="Your Name" required>
  <input type="email" name="email" placeholder="Your Email" required>
  <textarea name="message" placeholder="Your Message" required></textarea>
  <button type="submit">Send Message</button>
</form>

<?php
if (isset($_SESSION['logged_in'])) {
    // Fetch and show data from DB
    $pdo = new PDO("mysql:host=localhost;dbname=portfolio_db", "root", "");
    $contacts = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC")->fetchAll();
    echo "<h3>User Messages</h3><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Message</th><th>Date</th></tr></thead><tbody>";
    foreach ($contacts as $row) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['message']}</td>
                <td>{$row['created_at']}</td>
              </tr>";
    }
    echo "</tbody></table>";
}
?>
</div>
</body>
</html>
