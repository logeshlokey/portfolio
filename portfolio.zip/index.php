<?php
session_start();

// Handle login form submit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login_submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === 'logesh' && $password === '2005') {
        $_SESSION['logged_in'] = true;
        header("Location: contact.php");
        exit;
    } else {
        $error = "Invalid credentials. Try again.";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Logesh V - Frontend Developer | frontendzone</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        /* Your existing CSS here (copy all from your code above) */
                    * {
                padding: 0;
                margin: 0;
                box-sizing: border-box;
                font-family: sans-serif;
                text-decoration: none;
            }
            :root {
                --width: 90%;
                --bg: #0f051e;
            }
            body {
                background: var(--bg);
            }
            .btn {
                padding: 15px 35px;
                background: linear-gradient(to left, #4200fc, #f901fc);
                border-radius: 30px;
                color: #fff;
                font-size: 18px;
            }
            #navbar-iframe-container {
                display: none;
            }

            header nav {
                width: var(--width);
                margin: auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 100px;
                padding-top: 20px;
                z-index: 100;
                position: relative;
            }
            header nav .logo {
                font-size: 35px;
                font-weight: bold;
                background: linear-gradient(to left, #4200fc, #f901fc);
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
            }
            header .nav-links {
                transition: all 0.3s;
            }
            header nav .nav-links a {
                color: #fff;
                margin-left: 50px;
                position: relative;
            }
            header nav .nav-links a::after {
                content: "";
                position: absolute;
                bottom: -8px;
                left: 0;
                width: 0%;
                height: 3px;
                background: linear-gradient(to left, #4200fc, #f901fc);
                transition: 0.3s;
            }
            header nav .nav-links a:hover::after {
                width: 100%;
            }

            .content {
                padding-top: 70px;
                display: flex;
                width: var(--width);
                margin: auto;
                justify-content: space-between;
                align-items: center;
            }
            .content h1 {
                color: #fff;
                font-size: clamp(20px, 7vw, 60px);
                margin-bottom: 15px;
            }
            .content span {
                background: linear-gradient(to left, #4200fc, #f901fc);
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                font-size: clamp(20px, 7vw, 60px);
                font-weight: bold;
                letter-spacing: 1.5px;
            }
            .content p {
                color: #fff;
                margin-top: 50px;
                margin-bottom: 40px;
                line-height: 1.5;
            }
            .hero-img {
                border: 6px solid #f901fc;
                background-color: #07021a;
                border-radius: 10px;
                margin-right: 60px;
                border-radius: 50%;
                overflow: hidden;
                min-width: max-content;
                min-height: max-content;
               
            }
            .hero-img img {
                width: 25vw;
                height: 25vw;
                min-width: 150px;
                min-height: 150px;
            }

            .social-links {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                display: flex;
                right: 20px;
                flex-direction: column;
                gap: 25px;
                padding: 10px 0;
                background: var(--bg);
                z-index: 2;
                text-align: center;
            }
            .social-links a {
                color: #fff;
                font-size: 22px;
                transition: 0.4s;
            }
            .social-links a:hover {
                transform: scale(1.4);
            }
            .social-links span {
                color: #fff;
                font-weight: 500;
                transform: rotate(90deg);
                margin-bottom: 40px;
            }

            .menu {
                display: none;
                outline: none;
                border: none;
                width: 60px;
                height: 60px;
                margin-right: -17px;
                background: transparent;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                cursor: pointer;
            }
            .menu span {
                height: 2.6px;
                width: 25px;
                transition: all 0.2s;
                display: block;
                margin-bottom: 5px;
                background: #ddd;
            }
            .menu.active span:nth-of-type(2) {
                opacity: 0;
                width: 0px;
            }
            .menu.active span:nth-of-type(1) {
                transform: rotate(45deg);
                transform-origin: left;
            }
            .menu.active span:nth-of-type(3) {
                transform: translateY(3px) rotate(-45deg);
                transform-origin: left;
            }
            @media (min-width: 768px) {
                .hero-text .btn {
                    margin-top: 20px;
                    display: inline-block;
                }
                .hero-text p{width: 70%;}
            }
            .login-btn {
    padding: 10px 25px;
    background: linear-gradient(to left, #4200fc, #f901fc);
    border: none;
    border-radius: 30px;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s ease;
    margin-left: 20px;
}

.login-btn:hover {
    background: linear-gradient(to left, #f901fc, #4200fc);
    transform: scale(1.05);
}
header nav {
    width: var(--width);
    margin: auto;
    display: flex;
    justify-content: space-between; /* logo left, nav-right right */
    align-items: center;
    height: 100px;
    padding-top: 20px;
}

.nav-right {
    display: flex;
    align-items: center;
    gap: 15px; /* adjust spacing between links and buttons */
}

.nav-links {
    display: flex;
    gap: 15px;
}

.nav-links a {
    color: #fff;
    position: relative;
}

.btn, .login-btn {
    padding: 8px 16px;  /* smaller size for subscribe/login/logout buttons */
    font-size: 14px;
    border-radius: 20px;
}
            @media (max-width: 767px) {
                header .menu {
                    display: inline-flex;
                }
                .content {
                    gap: 60px;
                    padding-top: 20px;
                    flex-direction: column;
                }
                .btn {
                    padding: 8px 16px;
                    font-size: 15px;
                }
                .hero-img {
                    margin-right: 0;
                }
                .content span {
                    letter-spacing: 0;
                }

                header nav {
                    padding-top: 0;
                }
                .nav-links,
                .nav-links .btn {
                    display: none;
                }
                header:has(.menu.active) .nav-links {
                    position: fixed;
                    top: 0;
                    flex-direction: column;
                    display: flex;
                    gap: 10px;
                    left: 0;
                    height: 100%;
                    width: 70%;
                    padding-top: 50px;
                    min-height: 60vh;
                    background: var(--bg);
                    z-index: 2;
                }
                header nav .nav-links a {
                    margin-left: 24px;
                    padding: 10px 0;
                }
                .social-links {
                    position: fixed;
                    flex-direction: row;
                    top: unset;
                    bottom: 0;
                    right: 0;
                    left: 0;
                    width: 100%;
                    gap: 30px;
                    align-items: center;
                    justify-content: center;
                    height: 60px;
                    transform: none;
                }
                .social-links span {
                    transform: none;
                    margin-bottom: 0;
                }
                .content p {
                    margin-top: 17px;
                }
                .content h1 {
                    margin-bottom: 9px;
                }
                .container {
                    padding-bottom: 70px;
                }
                header nav .logo {
                    font-size: 30px;
                }
            }
    </style>
</head>
<body>
<div class="container">
    <header>
<nav>
  <a href="#" class="logo">Portfolio</a>
  <div class="nav-right">
    <div class="nav-links">
      <a href="index.php">Home</a>
      <a href="about.html">About</a>
      <a href="certificate.html">Certificate</a>
      <a href="projects.html">Projects</a>
      <a href="contact.php">Contact</a>
    </div>
    <?php if (isset($_SESSION['logged_in'])): ?>
      <a href="?logout=1" class="btn">Logout</a>
    <?php else: ?>
      <button class="login-btn" onclick="document.getElementById('login-form').style.display='block';">Login</button>
    <?php endif; ?>
    <a href="https://www.youtube.com/" class="btn">Subscribe</a>
  </div>
</nav>
</header>


<div class="content">
    <div class="hero-text">
        <h1>Logesh V</h1>
        <span>Full-Stack Developer</span>
        <p>Aspiring <b>Full Stack Developer</b> with strong skills in HTML, CSS, JavaScript, React, and MERN stack.
          Seeking an opportunity to contribute to web application development projects while gaining hands-on
          experience and expanding my technical expertise in a collaborative environment</p>
        <a href="https://www.linkedin.com/in/logesh-v-058a82270" class="btn" target="_blank">Follow LinkedIn</a>
    </div>
    <div class="hero-img">
        <img src="logo.avif" alt="Logo">
    </div>
</div>

<div id="login-form" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%);
 background:#1e1e2f; padding:30px; border-radius:10px; z-index:10; box-shadow:0 0 15px #f901fc;">
  <h3 style="color:#f901fc; text-align:center;">Login</h3>
  <?php if (!empty($error)) echo "<p style='color:red; text-align:center;'>$error</p>"; ?>
  <form method="POST">
    <input type="text" name="username" placeholder="Enter username" required style="width:100%;margin:10px 0;padding:10px;">
    <input type="password" name="password" placeholder="Enter password" required style="width:100%;margin:10px 0;padding:10px;">
    <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
      <button type="submit" name="login_submit" style="padding:10px 20px; background:#f901fc; border:none; border-radius:5px; color:#fff; cursor:pointer;">Login</button>
      <button type="button" onclick="document.getElementById('login-form').style.display='none';" style="padding:10px 20px; background:#555; border:none; border-radius:5px; color:#fff; cursor:pointer;">Cancel</button>
    </div>
  </form>
</div>

</div>
</body>
</html>